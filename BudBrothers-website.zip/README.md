# GetBudBrothers.com

Bud Brothers responsive brand website starter.

## Files
- `index.html` — homepage
- `style.css` — responsive visual design
- `script.js` — age gate and mobile navigation

## Deploy
This is a static HTML/CSS/JS site and can be deployed through Cloudflare Pages using the GitHub repository.

## Before publishing
Replace placeholder contact details and make sure all age, licensing, advertising, product, and other legal requirements applicable to the business and location are satisfied.
