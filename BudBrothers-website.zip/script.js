const enterBtn = document.getElementById("enterBtn");
const leaveBtn = document.getElementById("leaveBtn");
const ageGate = document.getElementById("ageGate");
const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

if (sessionStorage.getItem("bb_age_ok") === "yes") {
  document.body.classList.add("age-verified");
}

enterBtn.addEventListener("click", () => {
  sessionStorage.setItem("bb_age_ok", "yes");
  document.body.classList.add("age-verified");
});

leaveBtn.addEventListener("click", () => {
  window.location.href = "https://www.google.com/";
});

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

navLinks.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => navLinks.classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();
